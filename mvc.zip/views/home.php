<h1><?= e($title ?? 'Home') ?></h1>
<p class="sub"><?= e($message ?? '') ?></p>

<p>
    <strong>Standard Web:</strong>
    <a href="<?= route('/login') ?>">Login</a> |
    <a href="<?= route('/register') ?>">Register</a> |
    <a href="<?= route('/profile') ?>">My Profile</a> |
    <a href="<?= route('/phpinfo') ?>">PHP Info</a> |
    <a href="<?= route('/logout') ?>">Logout</a>
</p>

<p>
    <strong>Fuse (SPA):</strong>
    <a href="<?= route('/docs') ?>" fuse:navigate>Docs</a>
    <a href="<?= route('/fuse/native') ?>" fuse:navigate>Native Functions</a> |
    <a href="<?= route('/fuse-test') ?>" fuse:navigate>Test Page</a> |
    <a href="<?= route('/music') ?>" fuse:navigate>Music Player</a> |
    <a href="<?= route('/fuse/login') ?>" fuse:navigate>Login</a> |
    <a href="<?= route('/fuse/register') ?>" fuse:navigate>Register</a> |
    <a href="<?= route('/fuse/profile') ?>" fuse:navigate.hover>Profile</a>
</p>

<div class="mt-8">
    <?= fuse('MusicPlayer') ?>
</div>