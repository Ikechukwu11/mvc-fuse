<h1><?= e($title ?? 'Secret') ?></h1>
<p>Only authenticated users can see this.</p>

